﻿using Restaurant.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant.Infrastructure.Persistance.DTO
{
    public class UpdateRestaurantDetails
    {
        public string Restaurant { get; set; }
        public string Specialities { get; set; }
        public string AdditionalFeatures { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
    }
}
