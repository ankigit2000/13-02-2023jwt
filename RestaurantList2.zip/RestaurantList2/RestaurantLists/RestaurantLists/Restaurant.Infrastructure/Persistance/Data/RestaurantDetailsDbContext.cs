﻿using Microsoft.EntityFrameworkCore;
using Restaurant.Infrastructure.Persistance.DTO;
using Restaurant.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant.Infrastructure.Persistance.Data
{
    public class RestaurantDetailsDbContext : DbContext
    {
        public RestaurantDetailsDbContext(DbContextOptions<RestaurantDetailsDbContext> options) : base(options)
        {

        }
        public DbSet<Domain.Entities.RestaurantDetails>RestaurantDetails { get; set; }
        public DbSet<Users> Users { get; set; }
        public DbSet<Role> Roles { get; set; }
        public DbSet<Domain.Entities.RestaurantCity> City { get; set; }
        public DbSet<Domain.Entities.RestaurantState> State { get; set; }
        public DbSet<Domain.Entities.RestaurantLocation> Location { get; set; }
        public DbSet<Domain.Entities.RestaurantMenuItems> MenuItems { get; set; }
    }

}
