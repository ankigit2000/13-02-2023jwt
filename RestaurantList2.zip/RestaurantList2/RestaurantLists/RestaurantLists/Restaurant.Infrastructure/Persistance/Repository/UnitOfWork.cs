﻿using Microsoft.EntityFrameworkCore;
using Restaurant.Infrastructure.Persistance.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant.Infrastructure.Persistance.Repository
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly RestaurantDetailsDbContext _restaurantDetailsDbContextContext;
       
        private readonly Dictionary<Type, object> _repositories = new Dictionary<Type, object>();

        public UnitOfWork(RestaurantDetailsDbContext restaurantDetailsDbContextContext)
        {
            _restaurantDetailsDbContextContext = restaurantDetailsDbContextContext;
        }

        public RestaurantDetailsDbContext RestaurantDetailsDbContext
        {
            get { return _restaurantDetailsDbContextContext; }
        }
        public async Task<int> CommitAsync()
        {
            using (var transaction = _restaurantDetailsDbContextContext.Database.BeginTransaction())
            {
                try
                {
                    var result = await _restaurantDetailsDbContextContext.SaveChangesAsync();
                    transaction.Commit();
                    return result;
                }
                catch (Exception)
                {
                    transaction.Rollback();
                    throw;
                }
            }
        }

        public void Dispose()
        {
            //throw new NotImplementedException();
        }
    }
}
