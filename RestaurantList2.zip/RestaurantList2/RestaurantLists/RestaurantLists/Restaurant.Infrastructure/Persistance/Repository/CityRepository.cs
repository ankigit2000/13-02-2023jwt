﻿using Microsoft.EntityFrameworkCore;
using Restaurant.Domain.Repositories;
using Restaurant.Domain.Repositories.Base;
using Restaurant.Infrastructure.Persistance.Data;
using Restaurant.Infrastructure.Persistance.DTO;
using Restaurant.Infrastructure.Persistance.Repository.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant.Infrastructure.Persistance.Repository
{
    public class CityRepository : Repository<Restaurant.Domain.Entities.RestaurantCity>, ICityRepository
    {
        private readonly RestaurantDetailsDbContext restaurantDetailsDbContext;

        public CityRepository(IUnitOfWork unitOfWork) : base(unitOfWork)
        {
        }
    }
}
