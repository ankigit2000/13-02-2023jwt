﻿using Restaurant.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant.Application.Common.Interfaces
{
    public interface IStateService
    {
        Task<IEnumerable<RestaurantState>> GetAllAsync();
        Task<RestaurantState> GetAsync(int id);

        Task<RestaurantState> AddAsync(RestaurantState state);

        Task<RestaurantState> DeleteAsync(int id);

        Task<RestaurantState> UpdateAsync(int id, RestaurantState updated);
    }
}
