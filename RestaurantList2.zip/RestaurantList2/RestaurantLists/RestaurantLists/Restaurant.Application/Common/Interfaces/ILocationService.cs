﻿using Restaurant.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant.Application.Common.Interfaces
{
    public interface ILocationService
    {
        Task<IEnumerable<RestaurantLocation>> GetAllAsync();
        Task<RestaurantLocation> GetAsync(int id);

        Task<RestaurantLocation> AddAsync(RestaurantLocation location);

        Task<RestaurantLocation> DeleteAsync(int id);

        Task<RestaurantLocation> UpdateAsync(int id, RestaurantLocation updated);
    }
}
