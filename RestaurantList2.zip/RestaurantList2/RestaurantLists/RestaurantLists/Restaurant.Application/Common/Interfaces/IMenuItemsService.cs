﻿using Restaurant.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant.Application.Common.Interfaces
{
    public interface IMenuItemsService
    {
        Task<IEnumerable<RestaurantMenuItems>> GetAllAsync();
        Task<RestaurantMenuItems> GetAsync(int id);

        Task<RestaurantMenuItems> AddAsync(RestaurantMenuItems menuItems);

        Task<RestaurantMenuItems> DeleteAsync(int id);

        Task<RestaurantMenuItems> UpdateAsync(int id, RestaurantMenuItems updated);
    }
}
