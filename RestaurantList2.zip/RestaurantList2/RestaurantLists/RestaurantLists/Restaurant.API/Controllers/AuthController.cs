﻿using Microsoft.AspNetCore.Mvc;
using Restaurant.Application.Common.Interfaces;
using Restaurant.Domain.Entities;

namespace Restaurant.API.Controllers
{
    public class AuthController : Controller
    {
        private readonly IUserRepository userRepository;
        private readonly ITokenHandler tokenHandler;

        public AuthController(IUserRepository _userRepository, ITokenHandler _tokenHandler)
        {
            this.userRepository = _userRepository;
            this.tokenHandler = _tokenHandler;

        }


        [HttpPost]
        [Route("login")]
        public async Task<IActionResult> LoginAsync(Login login)
        {
            var user = await userRepository.AuthenticateAsync(login.username, login.password);

            if (user == null)
            {
                return BadRequest(new { message = "Username or password is incorrect" });
            }

            var token = await tokenHandler.CreateTokenAsync(user);

            return Ok(new
            {
                token = token,
                Message = "Login Success!",
                RoleID = user.RoleID,


            });
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] Register register)
        {
            var userExists = await userRepository.FindByNameAsync(register.Username);
            if (userExists != null)
                return StatusCode(StatusCodes.Status500InternalServerError, new { Message = "User already exists!" });

            var result = await userRepository.RegisterAsync(register.Username, register.Email, register.Password,register.ConfirmPassword, register.RoleId);
            var user = await userRepository.AuthenticateAsync(register.Username, register.Password);

            if (result == null)
                return StatusCode(StatusCodes.Status500InternalServerError, new { Message = "User creation failed! Please check user details and try again." });

            return Ok(new
            {
                Id = user.UserID,
                Username = user.Username,
                Email = user.Email,
                Password = register.Password,
                ConfirmPassword = register.ConfirmPassword,
                Message = "User created successfully!"
            });
        }
    }
}