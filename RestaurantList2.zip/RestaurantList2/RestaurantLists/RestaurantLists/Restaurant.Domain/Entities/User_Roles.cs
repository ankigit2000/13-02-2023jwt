﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant.Domain.Entities
{
    public class User_Roles
    {
        public Guid User_RolesID { get; set; }

        public Guid UserID { get; set; }
        public Users User { get; set; }

        //  public Guid RoleID { get; set; }
        // public Role Role { get; set; }
    }
}
